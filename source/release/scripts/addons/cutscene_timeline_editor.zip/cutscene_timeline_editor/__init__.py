"""
ADDON DE EDIÇÃO (roda no Blender/Range, NÃO é um componente de jogo).

Instalação: Preferences > Add-ons > Install... > selecione este arquivo >
marque a caixinha para ativar. Depois disso ele carrega sozinho toda vez
que o Blender/Range abrir, sem precisar rodar nada manualmente.

Ele registra um painel "Cutscene Timeline" em Properties > Scene, com a
mesma função do Tools/CutsceneEditor.py (editor tkinter standalone), mas
nativo em bpy — sem depender de Tcl/Tk, que nem sempre vem compilado
junto do Python embutido no Blender 2.79.

Por que isso existe:
O Tools/CutsceneEditor.py é um programa tkinter separado (roda fora do
Blender, com um Python de sistema) e edita o mesmo
scripts/cutscenes/cutscenes_data.json que o jogo lê em runtime. Este
addon oferece a alternativa "morando" dentro do próprio Blender/Range,
usando PropertyGroup/CollectionProperty/UIList/Operator nativos.

Estrutura de dados (idêntica ao JSON usado pelo jogo):
    { "nome_da_cena": { "1": [ {"action": "...", "params": {...}}, ... ] } }
"""

bl_info = {
    "name": "Cutscene Timeline Editor",
    "author": "Anastacio Games",
    "version": (1, 0, 0),
    "blender": (2, 79, 0),
    "location": "Properties > Scene > Cutscene Timeline",
    "description": "Editor nativo (bpy) da timeline de cutscenes, sem depender de tkinter",
    "category": "Scene",
}

import os
import json
from collections import OrderedDict

import bpy
import bpy.utils.previews
from bpy.props import (
    StringProperty, FloatProperty, IntProperty, BoolProperty,
    EnumProperty, CollectionProperty, PointerProperty,
)

# --- ÍCONES CUSTOMIZADOS (PNG rasterizado dos emojis do Tools/CutsceneEditor.py) ---
# A fonte de UI do Blender/Range 2.79 não tem glifos de emoji (viravam "tofu"),
# por isso os ícones são bitmaps pré-gerados em scripts/icons/<action>.png,
# carregados via bpy.utils.previews e usados com icon_value (não icon=).
_ICONS_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "icons")
_preview_collections = {}


def get_action_icon_id(action_key):
    pcoll = _preview_collections.get("main")
    if pcoll is None or action_key not in pcoll:
        return 0
    return pcoll[action_key].icon_id


# --- DEFINIÇÕES DE AÇÕES (mesmo catálogo do Tools/CutsceneEditor.py) ---
# Cada entrada: label e a lista de nomes de propriedade de CutsceneStepItem
# mostrados quando essa ação é escolhida. Sem emoji: a fonte de UI da Range
# não tem esses glifos e eles aparecem como "tofu" (quadrado vazio).
ACTION_DEFS = OrderedDict([
    # --- Diálogo ---
    ("dialog", {
        "label": "Diálogo / Fala",
        "fields": ["text_en", "text_pt", "text_es", "text_ru", "audio", "live"],
    }),
    ("hide_dialog", {
        "label": "Fechar Legendas de Diálogo",
        "fields": [],
    }),

    # --- Câmera ---
    ("camera_shot", {
        "label": "Tomada de Câmera",
        "fields": ["order"],
    }),
    ("look_at", {
        "label": "Focar Objeto (.lookAt)",
        "fields": ["target", "lerp"],
    }),
    ("restore_gameplay_camera", {
        "label": "Restaurar Câmera de Gameplay",
        "fields": ["gameplay_camera_name"],
    }),
    ("camera_start", {
        "label": "Iniciar Percurso de Câmeras (CutsceneCameraManager)",
        "fields": [],
    }),
    ("camera_stop", {
        "label": "Parar Percurso de Câmeras (CutsceneCameraManager)",
        "fields": [],
    }),

    # --- Player ---
    ("lock_player", {
        "label": "Travar Movimento do Player",
        "fields": ["anim", "enable_mouse"],
    }),
    ("unlock_player", {
        "label": "Destravar Controle do Player",
        "fields": [],
    }),
    ("player_anim", {
        "label": "Animação do Player",
        "fields": ["anim", "blend"],
    }),
    ("spawn_car", {
        "label": "Spawnar Carrinho/Piloto",
        "fields": ["empty_name", "car_name", "pilot_name"],
    }),

    # --- Interface / Mouse ---
    ("show_mouse", {
        "label": "Mostrar Mouse",
        "fields": [],
    }),
    ("hide_mouse", {
        "label": "Ocultar Mouse",
        "fields": [],
    }),

    # --- Cena ---
    ("change_scene", {
        "label": "Transição de Cena",
        "fields": ["target_scene"],
    }),

    # --- Espera / Sincronização ---
    ("wait_time", {
        "label": "Aguardar Tempo (Segundos)",
        "fields": ["seconds"],
    }),
    ("wait_trigger", {
        "label": "Aguardar Gatilho (Trigger)",
        "fields": ["trigger_name"],
    }),
])

ACTION_ITEMS = [(key, d["label"], d["label"]) for key, d in ACTION_DEFS.items()]

# Cache do dropdown com ícone: EnumProperty dinâmico precisa manter uma referência
# viva da lista retornada (bug conhecido do Blender - itens recém-criados a cada
# chamada podem crashar o dropdown), por isso guardamos em _action_items_cache.
_action_items_cache = []


def _get_action_items_with_icons(self, context):
    _action_items_cache.clear()
    for i, (key, d) in enumerate(ACTION_DEFS.items()):
        _action_items_cache.append((key, d["label"], d["label"], get_action_icon_id(key), i))
    return _action_items_cache


# --- PROPERTY GROUPS (estrutura em árvore: Cena > ID > Passo) ---

class CutsceneStepItem(bpy.types.PropertyGroup):
    action_type: EnumProperty(name="Ação", items=_get_action_items_with_icons)

    # dialog
    text_en: StringProperty(name="Texto EN")
    text_pt: StringProperty(name="Texto PT")
    text_es: StringProperty(name="Texto ES")
    text_ru: StringProperty(name="Texto RU")
    audio: StringProperty(name="Áudio", default="//sounds/{lang}/dublagem.ogg")
    live: BoolProperty(name="Modo Tempo Real", default=True)

    # wait_trigger
    trigger_name: StringProperty(name="Nome do Gatilho", default="gatilho 1")

    # wait_time
    seconds: FloatProperty(name="Segundos", default=2.0, min=0.0)

    # camera_shot
    order: IntProperty(name="Ordem da Tomada", default=1, min=1)

    # look_at
    target: StringProperty(name="Objeto Alvo", default="Spawn_Carro_Cutscene")
    lerp: FloatProperty(name="Suavização (Lerp)", default=1.0, min=0.01, max=1.0)

    # restore_gameplay_camera
    gameplay_camera_name: StringProperty(name="Nome da Câmera (opcional)", default="")

    # lock_player / player_anim (compartilham 'anim')
    anim: StringProperty(name="Animação")
    enable_mouse: BoolProperty(name="Manter Visão do Mouse", default=True)
    blend: IntProperty(name="Frames de Blend", default=8, min=0)

    # spawn_car
    empty_name: StringProperty(name="Empty de Spawn", default="Spawn_Carro_Cutscene")
    car_name: StringProperty(name="Carro (Opcional)")
    pilot_name: StringProperty(name="Piloto (Opcional)")

    # change_scene
    target_scene: StringProperty(name="Cena Alvo", default="GamePlay")


class CutsceneIDItem(bpy.types.PropertyGroup):
    id_value: StringProperty(name="ID", default="1")
    steps: CollectionProperty(type=CutsceneStepItem)
    steps_index: IntProperty()


class CutsceneSceneItem(bpy.types.PropertyGroup):
    scene_name: StringProperty(name="Cena", default="cutscene_01")
    ids: CollectionProperty(type=CutsceneIDItem)
    ids_index: IntProperty()


# --- HELPERS DE ACESSO AO ITEM ATIVO ---

def get_active_scene_item(scene):
    coll = scene.cutscene_timeline_data
    idx = scene.cutscene_timeline_data_index
    return coll[idx] if 0 <= idx < len(coll) else None


def get_active_id_item(sc_item):
    if not sc_item:
        return None
    idx = sc_item.ids_index
    return sc_item.ids[idx] if 0 <= idx < len(sc_item.ids) else None


def get_active_step_item(id_item):
    if not id_item:
        return None
    idx = id_item.steps_index
    return id_item.steps[idx] if 0 <= idx < len(id_item.steps) else None


# --- CONVERSÃO PARA/DE JSON (mesmo formato lido pelo jogo em runtime) ---

def load_step_params(step, action, params):
    step.action_type = action
    if action == "dialog":
        text_val = params.get("text", ["", "", "", ""])
        if isinstance(text_val, str):
            text_val = [text_val, text_val, text_val, text_val]
        elif isinstance(text_val, dict):
            text_val = [text_val.get("en", ""), text_val.get("pt", ""), text_val.get("es", ""), text_val.get("ru", "")]
        step.text_en = text_val[0] if len(text_val) > 0 else ""
        step.text_pt = text_val[1] if len(text_val) > 1 else ""
        step.text_es = text_val[2] if len(text_val) > 2 else ""
        step.text_ru = text_val[3] if len(text_val) > 3 else ""
        step.audio = params.get("audio", "")
        step.live = bool(params.get("live", True))
    elif action == "wait_trigger":
        step.trigger_name = params.get("name", "")
    elif action == "wait_time":
        step.seconds = float(params.get("seconds", 2.0))
    elif action == "camera_shot":
        step.order = int(params.get("order", 1))
    elif action == "look_at":
        step.target = params.get("target", "")
        step.lerp = float(params.get("lerp", 1.0))
    elif action == "restore_gameplay_camera":
        step.gameplay_camera_name = params.get("camera", "")
    elif action == "lock_player":
        step.anim = params.get("anim", "")
        step.enable_mouse = bool(params.get("enable_mouse", True))
    elif action == "spawn_car":
        step.empty_name = params.get("empty", "")
        step.car_name = params.get("car", "")
        step.pilot_name = params.get("pilot", "")
    elif action == "player_anim":
        step.anim = params.get("anim", "")
        step.blend = int(params.get("blend", 8))
    elif action == "change_scene":
        step.target_scene = params.get("scene", "")
    # unlock_player, hide_dialog, show_mouse e hide_mouse não têm parâmetros


def extract_step_params(step):
    action = step.action_type
    if action == "dialog":
        return {"text": [step.text_en, step.text_pt, step.text_es, step.text_ru], "audio": step.audio, "live": step.live}
    if action == "wait_trigger":
        return {"name": step.trigger_name}
    if action == "wait_time":
        return {"seconds": step.seconds}
    if action == "camera_shot":
        return {"order": step.order}
    if action == "look_at":
        return {"target": step.target, "lerp": step.lerp}
    if action == "restore_gameplay_camera":
        return {"camera": step.gameplay_camera_name}
    if action == "lock_player":
        return {"anim": step.anim, "enable_mouse": step.enable_mouse}
    if action == "spawn_car":
        return {"empty": step.empty_name, "car": step.car_name, "pilot": step.pilot_name}
    if action == "player_anim":
        return {"anim": step.anim, "blend": step.blend}
    if action == "change_scene":
        return {"scene": step.target_scene}
    return {}


def build_json_dict(scene):
    data = OrderedDict()
    for sc_item in scene.cutscene_timeline_data:
        ids_dict = OrderedDict()
        for id_item in sc_item.ids:
            ids_dict[id_item.id_value] = [
                {"action": st.action_type, "params": extract_step_params(st)} for st in id_item.steps
            ]
        data[sc_item.scene_name] = ids_dict
    return data


def save_json_to_disk(scene):
    """Grava a árvore de cenas/IDs/passos no arquivo JSON. Usado pelo botão 'Salvar' e pelo autosave."""
    path = bpy.path.abspath(scene.cutscene_json_path)
    data = build_json_dict(scene)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, ensure_ascii=False)
    return path


def autosave_if_enabled(context):
    """Salva automaticamente se 'cutscene_autosave' estiver ligado. Chamado após adicionar,
    remover ou mover um passo da timeline. Falha silenciosamente (não interrompe o operator)."""
    scene = context.scene
    if not getattr(scene, "cutscene_autosave", False):
        return
    try:
        save_json_to_disk(scene)
    except Exception as e:
        print(f"[CutsceneTimelineEditor] Autosave falhou: {e}")


# --- OPERATORS: CARREGAR / SALVAR JSON ---

class CUTSCENE_OT_load_json(bpy.types.Operator):
    bl_idname = "cutscene.load_json"
    bl_label = "Carregar Timeline"
    bl_description = "Recarrega a árvore de cenas/IDs/passos a partir do arquivo JSON"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        path = bpy.path.abspath(scene.cutscene_json_path)
        if not os.path.exists(path):
            self.report({'WARNING'}, f"Arquivo não encontrado: {path}")
            return {'CANCELLED'}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception as e:
            self.report({'ERROR'}, f"Erro ao ler JSON: {e}")
            return {'CANCELLED'}

        scene.cutscene_timeline_data.clear()
        for scene_name, ids_dict in data.items():
            sc_item = scene.cutscene_timeline_data.add()
            sc_item.scene_name = scene_name
            for id_value, steps in ids_dict.items():
                id_item = sc_item.ids.add()
                id_item.id_value = str(id_value)
                for step_data in steps:
                    st = id_item.steps.add()
                    load_step_params(st, step_data.get("action", ""), step_data.get("params", {}))

        self.report({'INFO'}, f"Timeline carregada de '{path}'")
        return {'FINISHED'}


class CUTSCENE_OT_save_json(bpy.types.Operator):
    bl_idname = "cutscene.save_json"
    bl_label = "Salvar Timeline"
    bl_description = "Grava a árvore de cenas/IDs/passos no arquivo JSON lido pelo jogo em runtime"
    bl_options = {'REGISTER'}

    def execute(self, context):
        scene = context.scene
        try:
            path = save_json_to_disk(scene)
        except Exception as e:
            self.report({'ERROR'}, f"Erro ao salvar JSON: {e}")
            return {'CANCELLED'}

        self.report({'INFO'}, f"Timeline salva em '{path}'")
        return {'FINISHED'}


# --- OPERATORS: CENAS ---

class CUTSCENE_OT_add_scene(bpy.types.Operator):
    bl_idname = "cutscene.add_scene"
    bl_label = "Nova Cena"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        coll = scene.cutscene_timeline_data
        item = coll.add()
        item.scene_name = f"cutscene_{len(coll):02d}"
        item.ids.add().id_value = "1"
        scene.cutscene_timeline_data_index = len(coll) - 1
        return {'FINISHED'}


class CUTSCENE_OT_remove_scene(bpy.types.Operator):
    bl_idname = "cutscene.remove_scene"
    bl_label = "Excluir Cena"
    bl_description = "Remove a cena selecionada e todos os seus IDs/passos"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        coll = scene.cutscene_timeline_data
        idx = scene.cutscene_timeline_data_index
        if 0 <= idx < len(coll):
            coll.remove(idx)
            scene.cutscene_timeline_data_index = max(0, idx - 1)
        return {'FINISHED'}


# --- OPERATORS: IDS ---

class CUTSCENE_OT_add_id(bpy.types.Operator):
    bl_idname = "cutscene.add_id"
    bl_label = "Novo ID"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        sc_item = get_active_scene_item(scene)
        if not sc_item:
            self.report({'WARNING'}, "Selecione uma cena primeiro.")
            return {'CANCELLED'}
        item = sc_item.ids.add()
        item.id_value = str(len(sc_item.ids))
        sc_item.ids_index = len(sc_item.ids) - 1
        return {'FINISHED'}


class CUTSCENE_OT_remove_id(bpy.types.Operator):
    bl_idname = "cutscene.remove_id"
    bl_label = "Excluir ID"
    bl_options = {'REGISTER', 'UNDO'}

    def invoke(self, context, event):
        return context.window_manager.invoke_confirm(self, event)

    def execute(self, context):
        scene = context.scene
        sc_item = get_active_scene_item(scene)
        if not sc_item:
            return {'CANCELLED'}
        idx = sc_item.ids_index
        if 0 <= idx < len(sc_item.ids):
            sc_item.ids.remove(idx)
            sc_item.ids_index = max(0, idx - 1)
        return {'FINISHED'}


# --- OPERATORS: PASSOS DA TIMELINE ---

class CUTSCENE_OT_add_step(bpy.types.Operator):
    bl_idname = "cutscene.add_step"
    bl_label = "Novo Passo"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        sc_item = get_active_scene_item(scene)
        id_item = get_active_id_item(sc_item)
        if not id_item:
            self.report({'WARNING'}, "Selecione um ID de cutscene primeiro.")
            return {'CANCELLED'}
        step = id_item.steps.add()
        step.action_type = next(iter(ACTION_DEFS))
        id_item.steps_index = len(id_item.steps) - 1
        autosave_if_enabled(context)
        return {'FINISHED'}


class CUTSCENE_OT_remove_step(bpy.types.Operator):
    bl_idname = "cutscene.remove_step"
    bl_label = "Remover Passo"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        sc_item = get_active_scene_item(scene)
        id_item = get_active_id_item(sc_item)
        if not id_item:
            return {'CANCELLED'}
        idx = id_item.steps_index
        if 0 <= idx < len(id_item.steps):
            id_item.steps.remove(idx)
            id_item.steps_index = max(0, idx - 1)
        autosave_if_enabled(context)
        return {'FINISHED'}


class CUTSCENE_OT_move_step(bpy.types.Operator):
    bl_idname = "cutscene.move_step"
    bl_label = "Mover Passo"
    bl_options = {'REGISTER', 'UNDO'}

    direction: EnumProperty(items=[('UP', "Up", ""), ('DOWN', "Down", "")])

    def execute(self, context):
        scene = context.scene
        sc_item = get_active_scene_item(scene)
        id_item = get_active_id_item(sc_item)
        if not id_item:
            return {'CANCELLED'}
        idx = id_item.steps_index
        new_idx = idx - 1 if self.direction == 'UP' else idx + 1
        if 0 <= new_idx < len(id_item.steps):
            id_item.steps.move(idx, new_idx)
            id_item.steps_index = new_idx
        autosave_if_enabled(context)
        return {'FINISHED'}


# --- UILISTS ---

class CUTSCENE_UL_scenes(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, "scene_name", text="", emboss=False, icon='SCENE_DATA')


class CUTSCENE_UL_ids(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        layout.prop(item, "id_value", text="", emboss=False, icon='LINENUMBERS_ON')


class CUTSCENE_UL_steps(bpy.types.UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        d = ACTION_DEFS.get(item.action_type, {})
        icon_id = get_action_icon_id(item.action_type)
        if icon_id:
            layout.label(text=d.get("label", item.action_type), icon_value=icon_id)
        else:
            layout.label(text=d.get("label", item.action_type))


# --- PAINEL PRINCIPAL (Properties > Scene) ---

class CUTSCENE_PT_timeline_editor(bpy.types.Panel):
    bl_label = "Cutscene Timeline"
    bl_space_type = 'PROPERTIES'
    bl_region_type = 'WINDOW'
    bl_context = "scene"

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        row = layout.row(align=True)
        row.prop(scene, "cutscene_json_path", text="")
        row.operator("cutscene.load_json", text="Load", icon_value=get_action_icon_id("open_folder"))
        row.operator("cutscene.save_json", text="Save", icon_value=get_action_icon_id("floppy_disk"))
        row.prop(scene, "cutscene_autosave", text="Auto Save", toggle=True, icon_value=get_action_icon_id("refresh"))

        box = layout.box()
        box.label(text="Cenas")
        row = box.row()
        row.template_list("CUTSCENE_UL_scenes", "", scene, "cutscene_timeline_data", scene, "cutscene_timeline_data_index", rows=3)
        col = row.column(align=True)
        col.operator("cutscene.add_scene", text="", icon_value=get_action_icon_id("plus"))
        col.operator("cutscene.remove_scene", text="", icon_value=get_action_icon_id("trash"))

        sc_item = get_active_scene_item(scene)
        if not sc_item:
            return

        box = layout.box()
        box.label(text=f"IDs de '{sc_item.scene_name}'")
        row = box.row()
        row.template_list("CUTSCENE_UL_ids", "", sc_item, "ids", sc_item, "ids_index", rows=3)
        col = row.column(align=True)
        col.operator("cutscene.add_id", text="", icon_value=get_action_icon_id("plus"))
        col.operator("cutscene.remove_id", text="", icon_value=get_action_icon_id("trash"))

        id_item = get_active_id_item(sc_item)
        if not id_item:
            return

        box = layout.box()
        box.label(text=f"Timeline (ID = {id_item.id_value})")
        row = box.row()
        row.template_list("CUTSCENE_UL_steps", "", id_item, "steps", id_item, "steps_index", rows=6)
        col = row.column(align=True)
        col.operator("cutscene.add_step", text="", icon_value=get_action_icon_id("plus"))
        col.operator("cutscene.remove_step", text="", icon_value=get_action_icon_id("trash"))
        col.separator()
        col.operator("cutscene.move_step", text="", icon='TRIA_UP').direction = 'UP'
        col.operator("cutscene.move_step", text="", icon='TRIA_DOWN').direction = 'DOWN'

        step = get_active_step_item(id_item)
        if not step:
            return

        box = layout.box()
        icon_id = get_action_icon_id(step.action_type)
        if icon_id:
            box.label(text="Detalhes do Passo", icon_value=icon_id)
        else:
            box.label(text="Detalhes do Passo")
        box.prop(step, "action_type")
        for field_name in ACTION_DEFS[step.action_type]["fields"]:
            box.prop(step, field_name)


CLASSES = (
    CutsceneStepItem,
    CutsceneIDItem,
    CutsceneSceneItem,
    CUTSCENE_OT_load_json,
    CUTSCENE_OT_save_json,
    CUTSCENE_OT_add_scene,
    CUTSCENE_OT_remove_scene,
    CUTSCENE_OT_add_id,
    CUTSCENE_OT_remove_id,
    CUTSCENE_OT_add_step,
    CUTSCENE_OT_remove_step,
    CUTSCENE_OT_move_step,
    CUTSCENE_UL_scenes,
    CUTSCENE_UL_ids,
    CUTSCENE_UL_steps,
    CUTSCENE_PT_timeline_editor,
)


def register():
    for cls in CLASSES:
        try:
            bpy.utils.unregister_class(cls)
        except (RuntimeError, ValueError):
            pass
        bpy.utils.register_class(cls)

    pcoll = bpy.utils.previews.new()
    if os.path.isdir(_ICONS_DIR):
        for fname in os.listdir(_ICONS_DIR):
            if fname.lower().endswith(".png"):
                key = os.path.splitext(fname)[0]
                pcoll.load(key, os.path.join(_ICONS_DIR, fname), 'IMAGE')
    _preview_collections["main"] = pcoll

    bpy.types.Scene.cutscene_timeline_data = CollectionProperty(type=CutsceneSceneItem)
    bpy.types.Scene.cutscene_timeline_data_index = IntProperty()
    bpy.types.Scene.cutscene_json_path = StringProperty(
        name="Arquivo JSON",
        subtype='FILE_PATH',
        default="//scripts/cutscenes/cutscenes_data.json",
    )
    bpy.types.Scene.cutscene_autosave = BoolProperty(
        name="Autosave",
        description="Salva o JSON automaticamente ao adicionar, remover ou mover uma ação da timeline",
        default=False,
    )


def unregister():
    del bpy.types.Scene.cutscene_autosave
    del bpy.types.Scene.cutscene_json_path
    del bpy.types.Scene.cutscene_timeline_data_index
    del bpy.types.Scene.cutscene_timeline_data

    for pcoll in _preview_collections.values():
        bpy.utils.previews.remove(pcoll)
    _preview_collections.clear()

    for cls in reversed(CLASSES):
        bpy.utils.unregister_class(cls)


# Como addon instalado (Preferences > Add-ons), Blender chama register()/unregister()
# sozinho ao (des)ativar a caixinha. O bloco abaixo só roda se você ainda executar
# este arquivo direto pelo "Run Script" no editor de textos (útil durante o desenvolvimento).
if __name__ == "__main__":
    register()
    print("[CutsceneTimelineEditor] Painel 'Cutscene Timeline' registrado em Properties > Scene.")
